import jupman;

DEBUG = True

def debug(msg):
    if DEBUG:
        print("DEBUG: ", msg.replace('\n', '\n' + (' '*8)))

class PyraStack:

    def __init__(self):        
        self._rows = []

    def __str__(self):        
        """ NOTE: rows are printed bottom-up
        """
        return "\n".join(''.join(row) for row in reversed(self._rows))    

    

    def drop(self, w):
        """ Drops a block of size w on the pyrastack, trying to place it on
            the top leftmost position without having missing blocks below.
            If top row is not feasible, scans for the first available leftmost 
            place which can fully accomodate the block.            

            - if w is negative, raise ValueError
            - if w is zero, no change is made

            - MUST run in O(h + w) where h is the stack height 
        """
        raise Exception('TODO IMPLEMENT ME !')

