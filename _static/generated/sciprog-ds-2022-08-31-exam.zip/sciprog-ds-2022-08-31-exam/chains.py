
def chain(external_list):
    """
        Takes a list of list of strings and return a list containing all 
        the strings  from external_list in sequence, joined by the ending 
        and starting strings of the internal lists. See tests for more examples.

        INPUT: a list of list of strings , like:

                [
                    ['ab', 'c', 'de'],
                    ['gh', 'i'],
                    ['de', 'f', 'gh']
                ]
                
        OUTPUT: a list of strings, like   ['ab', 'c', 'de', 'f', 'gh', 'i']


    """
    raise Exception('TODO IMPLEMENT ME !')


