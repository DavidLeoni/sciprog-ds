
def insertion_sort(A):
    """ Sorts in-place list A with insertion sort  

        Remember insertion sort has complexity O(n^2) where n is the 
        size of the list.
    """
    raise Exception('TODO IMPLEMENT ME !')