


class Bank:

    def __init__(self):
        """ Initializes an empty bank
        
            Add a data structure of your choice for indexing the log
        """
        self._trans = []
        raise Exception('TODO IMPLEMENT ME !')

    def __str__(self):
        """Already implemented, if you want you can add display of your own index (not mandatory)
        """
        return "%s: %s" % (self.__class__.__name__, ','.join(str(t) for t in self._trans))
        
    def log(self, transaction):
        """ Appends transaction to the log
        
            - REMEMBER to also update the index
            - MUST EXECUTE IN O(1)
        """
        raise Exception('TODO IMPLEMENT ME !')
    
    
    def pos(self, triseq):
        """ RETURN a NEW list with all the indeces where the sequence of 
            three transactions can be found
        
            - MUST execute in O(1)
        """
        raise Exception('TODO IMPLEMENT ME !')
        
    def revert(self):
        """ Completely eliminates last transaction and RETURN it

            - if bank is empty, raises IndexError
            
            - REMEMBER to update any index referring to it
            - *MUST* EXECUTE IN O(1) 
        """        
        raise Exception('TODO IMPLEMENT ME !')
        
    def max_interval(self, tri_start, tri_end):
        """ RETURN a list with all the transactions occurred between 
            the *largest* interval among tri-sequences tri_start and tri_end
        
            - tri_start and tri_end are EXCLUDED 
            - if tri_start / tri_end are not found, or if tri_end is before/includes tri_start, 
              raise LookupError

            
            - DO *NOT* MODIFY the data structure
            - MUST EXECUTE IN O(k) where k is the length of the *largest* interval you can return
            - consider number of repetitions a negligible size
        """
        raise Exception('TODO IMPLEMENT ME !')
